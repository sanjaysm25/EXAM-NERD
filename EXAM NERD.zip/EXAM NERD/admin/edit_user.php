<?php
session_start();
define('TITLE', 'dashboard.php');
define('page', 'dashboard.php');
include('includes/header.php');
include('../dbcon.php');

if (!isset($_SESSION['radmin'])) {
    header("location:adminlogin.php");
}

if (isset($_GET['uemail'])) {
    $uemail = $_GET['uemail'];

    
    $sql = "SELECT * FROM user WHERE email = '$uemail'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        ?>
        <div class="col-sm-9 col-md-10 text-center" id="gob">
            <p class="p-2 mt-2 text-white" style="background-color: rgba(0, 0, 0, 0.6);">Update User</p>
            <form action="update_user_process.php" method="POST">
                <input type="hidden" name="uemail" value="<?php echo $row['email']; ?>">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['name']; ?>">
                </div>
                <div class="form-group">
                    <label for="collage">College</label>
                    <input type="text" class="form-control" id="college" name="college" value="<?php echo $row['collage']; ?>">
                </div>
                <div class="form-group">
                    <label for="mobile">Mobile</label>
                    <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $row['mob']; ?>">
                </div>
                
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
        <?php
    } else {
        echo "User not found.";
    }
} else {
    echo "Invalid user email.";
}

include('includes/footer.php');
?>
