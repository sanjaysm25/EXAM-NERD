<?php
session_start();
include('../dbcon.php');


$updateMessage = "";


if (isset($_POST['uemail'], $_POST['name'], $_POST['college'], $_POST['mobile'])) {
    
    $uemail = mysqli_real_escape_string($conn, $_POST['uemail']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $college = mysqli_real_escape_string($conn, $_POST['college']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);

    
    $sql = "UPDATE user SET name = ?, collage = ?, mob = ? WHERE email = ?";
    
    
    if ($stmt = $conn->prepare($sql)) {
        
        $stmt->bind_param("ssss", $name, $college, $mobile, $uemail);

        
        if ($stmt->execute()) {
            $updateMessage = "User information updated successfully.";
            
            
            header("Location: dashboard.php");
            exit();
        } else {
            $updateMessage = "Error updating user information: " . $stmt->error;
        }

        
        $stmt->close();
    } else {
        $updateMessage = "Error preparing statement: " . $conn->error;
    }
} else {
    $updateMessage = "Invalid request.";
}


$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Add your HTML head content here -->
</head>
<body>
    <!-- Add your HTML body content here -->

    <!-- Display the update result message -->
    <div><?php echo $updateMessage; ?></div>
</body>
</html>
